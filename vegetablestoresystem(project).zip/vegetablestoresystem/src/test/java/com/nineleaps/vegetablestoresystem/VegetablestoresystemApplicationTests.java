package com.nineleaps.vegetablestoresystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VegetablestoresystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
