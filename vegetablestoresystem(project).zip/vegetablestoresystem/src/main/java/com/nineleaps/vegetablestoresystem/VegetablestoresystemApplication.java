package com.nineleaps.vegetablestoresystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VegetablestoresystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VegetablestoresystemApplication.class, args);
	}

}
