package com.nineleaps.vegetablestoresystem.exception;

public class SourceNotFoundException extends Exception {
	public SourceNotFoundException(String string) {
		super(string);
	}
}
